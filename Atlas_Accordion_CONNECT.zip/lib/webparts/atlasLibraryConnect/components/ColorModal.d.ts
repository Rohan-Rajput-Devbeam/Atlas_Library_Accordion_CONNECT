export default function ColorModal({ children }: {
    children: any;
}): JSX.Element;
//# sourceMappingURL=ColorModal.d.ts.map