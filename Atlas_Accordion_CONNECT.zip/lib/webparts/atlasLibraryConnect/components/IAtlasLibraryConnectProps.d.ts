import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IAtlasLibraryConnectProps {
    description: string;
    context: WebPartContext;
    people: any;
}
//# sourceMappingURL=IAtlasLibraryConnectProps.d.ts.map