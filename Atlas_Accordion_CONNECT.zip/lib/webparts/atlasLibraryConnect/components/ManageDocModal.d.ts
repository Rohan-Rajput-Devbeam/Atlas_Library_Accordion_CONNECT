import * as React from "react";
export default class ManageDocModal extends React.Component<any, any> {
    state: {
        show: boolean;
        setShow: boolean;
    };
    setShow(isOpen: any): void;
    render(): JSX.Element;
}
//# sourceMappingURL=ManageDocModal.d.ts.map