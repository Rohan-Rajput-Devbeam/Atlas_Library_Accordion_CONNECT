import * as React from 'react';
declare const FileIconContext: React.Context<{
    excelIcon: unknown;
    docxIcon: unknown;
    powerpointIcon: unknown;
    pdfIcon: unknown;
    imageIcon: unknown;
    videoIcon: unknown;
    otherIcon: unknown;
}>;
export default FileIconContext;
//# sourceMappingURL=FileIconContext.d.ts.map