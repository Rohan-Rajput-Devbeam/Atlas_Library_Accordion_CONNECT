import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
export declare class Example2 extends React.Component {
    constructor(props: any);
    render(): JSX.Element;
}
export default Example2;
//# sourceMappingURL=RackButton.d.ts.map