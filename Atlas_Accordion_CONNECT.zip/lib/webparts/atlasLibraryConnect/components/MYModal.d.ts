export declare const MYModal: (myprops: any) => JSX.Element;
//# sourceMappingURL=MYMODAL.d.ts.map