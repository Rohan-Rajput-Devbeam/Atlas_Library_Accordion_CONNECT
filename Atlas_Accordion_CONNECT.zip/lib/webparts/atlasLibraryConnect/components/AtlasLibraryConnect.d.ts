import * as React from 'react';
import { SPService } from '../Services/SPServices';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IAtlasLibraryConnectState {
    docItems: any;
    categories: any;
    currPageUrl: any;
    currUserGroups: any;
    displayFlag: boolean;
    callchildcomponent: boolean;
    swatchcolor: any;
    previewColor: any;
    color: any;
}
export interface IAtlasLibraryConnectProps {
    description: string;
    context: WebPartContext;
    people: any;
    gradientColor1: any;
    gradientColor2: any;
}
export default class AtlasLibraryConnect extends React.Component<IAtlasLibraryConnectProps, IAtlasLibraryConnectState> {
    SPService: SPService;
    static contextType: React.Context<{
        excelIcon: unknown;
        docxIcon: unknown;
        powerpointIcon: unknown;
        pdfIcon: unknown;
        imageIcon: unknown;
        videoIcon: unknown;
        otherIcon: unknown;
    }>;
    static dateOptions: {
        readonly year: "numeric";
        readonly month: "short";
        readonly day: "numeric";
        readonly weekday: "short";
        readonly hour: "numeric";
        readonly minute: "numeric";
    };
    rackName: string;
    hrefString: string;
    properties: any;
    constructor(props: IAtlasLibraryConnectProps);
    handler(): void;
    private Buttonclick;
    componentDidUpdate(): void;
    componentDidMount(): void;
    getAllDocs2(): Promise<void>;
    getUserGroups2(): Promise<void>;
    selectIcon(docName: any): any;
    categorize(): void;
    categorizeGroups(): void;
    render(): React.ReactElement<IAtlasLibraryConnectProps>;
    private _updateColor;
}
//# sourceMappingURL=AtlasLibraryConnect.d.ts.map