declare const styles: {
    atlasLibraryConnect: string;
    CardHeader: string;
    CollapseButton: string;
    titleSpan: string;
    live: string;
    pulse: string;
    'letter-image': string;
    'animated-mail': string;
    body: string;
    'top-fold': string;
    'back-fold': string;
    'left-fold': string;
    letter: string;
    'letter-border': string;
    'letter-title': string;
    'letter-context': string;
    'letter-stamp': string;
    shadow: string;
    submitBtn: string;
};
export default styles;
//# sourceMappingURL=AtlasLibraryConnect.module.scss.d.ts.map