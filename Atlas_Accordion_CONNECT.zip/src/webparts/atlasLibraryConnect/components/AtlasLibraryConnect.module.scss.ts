/* tslint:disable */
require("./AtlasLibraryConnect.module.css");
const styles = {
  atlasLibraryConnect: 'atlasLibraryConnect_6be04a6a',
  CardHeader: 'CardHeader_6be04a6a',
  CollapseButton: 'CollapseButton_6be04a6a',
  titleSpan: 'titleSpan_6be04a6a',
  live: 'live_6be04a6a',
  pulse: 'pulse_6be04a6a',
  'letter-image': 'letter-image_6be04a6a',
  'animated-mail': 'animated-mail_6be04a6a',
  body: 'body_6be04a6a',
  'top-fold': 'top-fold_6be04a6a',
  'back-fold': 'back-fold_6be04a6a',
  'left-fold': 'left-fold_6be04a6a',
  letter: 'letter_6be04a6a',
  'letter-border': 'letter-border_6be04a6a',
  'letter-title': 'letter-title_6be04a6a',
  'letter-context': 'letter-context_6be04a6a',
  'letter-stamp': 'letter-stamp_6be04a6a',
  shadow: 'shadow_6be04a6a',
  submitBtn: 'submitBtn_6be04a6a'
};

export default styles;
/* tslint:enable */