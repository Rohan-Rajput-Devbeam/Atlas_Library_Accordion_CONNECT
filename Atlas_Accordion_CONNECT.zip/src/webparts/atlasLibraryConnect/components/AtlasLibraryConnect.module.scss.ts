/* tslint:disable */
require("./AtlasLibraryConnect.module.css");
const styles = {
  atlasLibraryConnect: 'atlasLibraryConnect_0b28cdb0',
  addDocuments: 'addDocuments_0b28cdb0',
  docCard: 'docCard_0b28cdb0',
  docCardHeader: 'docCardHeader_0b28cdb0',
  modalXl: 'modalXl_0b28cdb0',
  CardHeader: 'CardHeader_0b28cdb0',
  CollapseButton: 'CollapseButton_0b28cdb0',
  downloadBut1: 'downloadBut1_0b28cdb0',
  titleSpan: 'titleSpan_0b28cdb0',
  live: 'live_0b28cdb0',
  pulse: 'pulse_0b28cdb0',
  colorPickerIcon: 'colorPickerIcon_0b28cdb0',
  'letter-image': 'letter-image_0b28cdb0',
  'animated-mail': 'animated-mail_0b28cdb0',
  body: 'body_0b28cdb0',
  'top-fold': 'top-fold_0b28cdb0',
  'back-fold': 'back-fold_0b28cdb0',
  'left-fold': 'left-fold_0b28cdb0',
  letter: 'letter_0b28cdb0',
  'letter-border': 'letter-border_0b28cdb0',
  'letter-title': 'letter-title_0b28cdb0',
  'letter-context': 'letter-context_0b28cdb0',
  'letter-stamp': 'letter-stamp_0b28cdb0',
  shadow: 'shadow_0b28cdb0',
  submitBtn: 'submitBtn_0b28cdb0'
};

export default styles;
/* tslint:enable */