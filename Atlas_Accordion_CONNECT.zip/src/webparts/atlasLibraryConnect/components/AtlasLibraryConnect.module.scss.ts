/* tslint:disable */
require("./AtlasLibraryConnect.module.css");
const styles = {
  atlasLibraryConnect: 'atlasLibraryConnect_8e5b9bca',
  CardHeader: 'CardHeader_8e5b9bca',
  CollapseButton: 'CollapseButton_8e5b9bca',
  titleSpan: 'titleSpan_8e5b9bca',
  live: 'live_8e5b9bca',
  pulse: 'pulse_8e5b9bca',
  colorPickerIcon: 'colorPickerIcon_8e5b9bca',
  'letter-image': 'letter-image_8e5b9bca',
  'animated-mail': 'animated-mail_8e5b9bca',
  body: 'body_8e5b9bca',
  'top-fold': 'top-fold_8e5b9bca',
  'back-fold': 'back-fold_8e5b9bca',
  'left-fold': 'left-fold_8e5b9bca',
  letter: 'letter_8e5b9bca',
  'letter-border': 'letter-border_8e5b9bca',
  'letter-title': 'letter-title_8e5b9bca',
  'letter-context': 'letter-context_8e5b9bca',
  'letter-stamp': 'letter-stamp_8e5b9bca',
  shadow: 'shadow_8e5b9bca',
  submitBtn: 'submitBtn_8e5b9bca'
};

export default styles;
/* tslint:enable */